fx_version 'cerulean'
game 'gta5'
files {
	'common/*.meta'
}
